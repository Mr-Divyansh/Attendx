import { NextRequest } from 'next/server'
import { cookies } from 'next/headers'
import { db } from '@/lib/db'
import {
  createCollegeSession,
  issueCsrfToken,
  errorResponse,
  handleRouteError,
} from '@/lib/auth'
import {
  exchangeGoogleCode,
  getGoogleOAuthConfig,
  OAuthConfigurationError,
  verifyOAuthState,
  OAUTH_STATE_COOKIE,
} from '@/lib/oauth'

type GoogleProfile = { sub: string; email: string; name: string }

async function upsertGoogleStudent(profile: GoogleProfile) {
  let user = await db.user.findUnique({
    where: { email: profile.email },
    include: { student: true, authAccounts: true },
  })

  if (!user) {
    user = await db.user.create({
      data: {
        email: profile.email,
        passwordHash: null,
        role: 'STUDENT',
        student: {
          create: {
            fullName: profile.name,
            rollNo: 'PENDING',
            hasRollNumber: true,
            profileComplete: false,
          },
        },
        authAccounts: {
          create: {
            provider: 'google',
            providerAccountId: profile.sub,
          },
        },
      },
      include: { student: true, authAccounts: true },
    })
  } else {
    if (user.role !== 'STUDENT') {
      throw new Error('ROLE_CONFLICT')
    }
    if (user.disabled) {
      throw new Error('DISABLED')
    }

    const account = await db.authAccount.findUnique({
      where: { provider_providerAccountId: { provider: 'google', providerAccountId: profile.sub } },
    })
    if (account && account.userId !== user.id) throw new Error('ACCOUNT_CONFLICT')
    if (!account) {
      await db.authAccount.create({
        data: { userId: user.id, provider: 'google', providerAccountId: profile.sub },
      })
    }

    if (!user.student) {
      user = await db.user.update({
        where: { id: user.id },
        data: {
          student: {
            create: {
              fullName: profile.name,
              rollNo: 'PENDING',
              hasRollNumber: true,
              profileComplete: false,
            },
          },
        },
        include: { student: true, authAccounts: true },
      })
    }
  }

  return user
}

async function upsertGoogleTeacher(profile: GoogleProfile) {
  let user = await db.user.findUnique({
    where: { email: profile.email },
    include: { teacher: true, authAccounts: true },
  })

  if (!user) {
    user = await db.user.create({
      data: {
        email: profile.email,
        passwordHash: null,
        role: 'TEACHER',
        teacher: {
          create: {
            fullName: profile.name,
            profileComplete: false,
          },
        },
        authAccounts: {
          create: {
            provider: 'google',
            providerAccountId: profile.sub,
          },
        },
      },
      include: { teacher: true, authAccounts: true },
    })
  } else {
    if (user.role !== 'TEACHER') {
      throw new Error('ROLE_CONFLICT')
    }
    if (user.disabled) {
      throw new Error('DISABLED')
    }

    const account = await db.authAccount.findUnique({
      where: { provider_providerAccountId: { provider: 'google', providerAccountId: profile.sub } },
    })
    if (account && account.userId !== user.id) throw new Error('ACCOUNT_CONFLICT')
    if (!account) {
      await db.authAccount.create({
        data: { userId: user.id, provider: 'google', providerAccountId: profile.sub },
      })
    }

    if (!user.teacher) {
      user = await db.user.update({
        where: { id: user.id },
        data: {
          teacher: {
            create: {
              fullName: profile.name,
              profileComplete: false,
            },
          },
        },
        include: { teacher: true, authAccounts: true },
      })
    }
  }

  return user
}

export async function GET(req: NextRequest) {
  try {
    const config = getGoogleOAuthConfig(req)
    const appUrl = config.appUrl
    const code = req.nextUrl.searchParams.get('code')
    const state = req.nextUrl.searchParams.get('state')
    const oauthError = req.nextUrl.searchParams.get('error')

    if (oauthError) {
      return Response.redirect(`${appUrl}/?auth_error=${encodeURIComponent(oauthError)}`)
    }

    if (!code || !state) {
      return Response.redirect(`${appUrl}/?auth_error=missing_code`)
    }

    const store = await cookies()
    const cookieState = store.get(OAUTH_STATE_COOKIE)?.value
    store.delete(OAUTH_STATE_COOKIE)

    if (!cookieState || cookieState !== state) {
      return Response.redirect(`${appUrl}/?auth_error=invalid_state`)
    }

    const parsed = verifyOAuthState(state)
    if (!parsed || (parsed.role !== 'STUDENT' && parsed.role !== 'TEACHER')) {
      return Response.redirect(`${appUrl}/?auth_error=invalid_state`)
    }

    try {
      const profile = await exchangeGoogleCode(code, config)

      if (parsed.role === 'TEACHER') {
        const user = await upsertGoogleTeacher(profile)
        await createCollegeSession({
          id: user.id,
          email: user.email,
          role: 'TEACHER',
        })
        await issueCsrfToken()
        const needsProfile = !user.teacher?.profileComplete
        return Response.redirect(
          needsProfile
            ? `${appUrl}/?teacher_setup=1`
            : `${appUrl}/?teacher_login=1`
        )
      }

      const user = await upsertGoogleStudent(profile)
      const student = user.student!

      const needsProfile =
        !student.profileComplete ||
        student.rollNo === 'PENDING' ||
        !student.studentType

      await createCollegeSession({
        id: user.id,
        email: user.email,
        role: 'STUDENT',
      })
      await issueCsrfToken()

      const redirect = needsProfile
        ? `${appUrl}/?student_setup=1`
        : `${appUrl}/?student_login=1`
      return Response.redirect(redirect)
    } catch (e) {
      const msg = e instanceof Error ? e.message : 'oauth_failed'
      if (msg === 'ROLE_CONFLICT') {
        return Response.redirect(`${appUrl}/?auth_error=role_conflict`)
      }
      if (msg === 'DISABLED') {
        return Response.redirect(`${appUrl}/?auth_error=account_disabled`)
      }
      if (msg === 'ACCOUNT_CONFLICT') {
        return Response.redirect(`${appUrl}/?auth_error=account_conflict`)
      }
      console.error('[auth/google/callback] failed', {
        code: msg === 'GOOGLE_TOKEN_EXCHANGE_FAILED' || msg === 'GOOGLE_PROFILE_VERIFICATION_FAILED'
          ? msg
          : 'OAUTH_CALLBACK_FAILED',
      })
      return Response.redirect(`${appUrl}/?auth_error=oauth_failed`)
    }

  } catch (e) {
    if (e instanceof OAuthConfigurationError) {
      console.error('[auth/google/callback] configuration error', { code: e.code })
      return Response.redirect(`${new URL(req.url).origin}/?auth_error=oauth_unavailable`)
    }
    return handleRouteError(e, 'auth/google/callback')
  }
}
